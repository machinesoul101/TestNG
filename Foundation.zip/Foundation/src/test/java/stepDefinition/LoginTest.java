package stepDefinition;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.LoginPOM;

public class LoginTest {
	
	private WebDriver driver=Hooks.driver;
	
	@Given("User already opened the website nopcommerce")
	public void user_already_opened_the_website_nopcommerce() {
		assertEquals("https://demo.nopcommerce.com/", driver.getCurrentUrl());
	}

	@When("User input {string} as username {string} as password")
	public void user_input_as_username_as_password(String uname, String pass) {
		LoginPOM login=new LoginPOM(driver);
		login.clickloginicon();
		login.sendemail(uname);
		login.sendpass(pass);
		login.loginbtn();
	}

	@Then("User at homepage")
	public void User_at_homepage() {
		assertEquals("https://demo.nopcommerce.com/",driver.getCurrentUrl());

	}

	@Then("User got {string} as error message")
	public void user_got_as_error_message(String string) {
		assertEquals("https://demo.nopcommerce.com/login?returnUrl=%2F", driver.getCurrentUrl());
	}

}
