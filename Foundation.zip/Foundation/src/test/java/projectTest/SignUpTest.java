package projectTest;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.ExcelHandling;
import base.ReusableFunction;
import pom.SignUpPOM;
import utilities.ExtentReportsListener;


@Listeners(utilities.ExtentReportsListener.class)
public class SignUpTest implements ITestListener{

	ExtentReportsListener extentReportsListener = new ExtentReportsListener();
	public WebDriver driver;
	public ReusableFunction reusableFunctions;
	public SignUpPOM register;
	
	@BeforeClass
	public void before() {
		// Initialize reusable functions and browser invocation before the test class
		reusableFunctions=new ReusableFunction(driver);
		driver = ReusableFunction.invokeBrowser();
	}
	
	@BeforeMethod
	public void getsite() {
		// Open the test site before each test method
		reusableFunctions.openBrowser("testSiteURL");
	}
	@Test(priority = 1)
	public void InvalidRegister() {
		register=new SignUpPOM(driver);
		register.RegisterIcon();
		register.clickregbtn();
		driver.navigate().back();
	}
	
	@Test(dataProvider = "validRegister",priority = 2)
	public void testValidregister(String firstname,String lastname,String email,String pass,String confirmpass,String company) {
		register=new SignUpPOM(driver);
		register.RegisterIcon();
		register.PassData(firstname,lastname,email,pass,confirmpass,company);
		register.clickregbtn();
		assertEquals("https://demo.nopcommerce.com/registerresult/1?returnUrl=/", driver.getCurrentUrl());
	}
	
	
	
	@DataProvider(name="validRegister")
	public String[][] getData() throws IOException{
		String path=System.getProperty("user.dir")+"\\TestData\\details.xlsx";
		String sheetName="Sheet1";
		return ExcelHandling.excelHandling(path,sheetName);
	}
	
	
	@AfterMethod
	public void FailScreenshot(ITestResult result) {
		if(result.getStatus() == ITestResult.FAILURE) {
			try {
				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File(System.getProperty("user.dir")+"/screenshots/"+ d1.getTime()+ "ss.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
