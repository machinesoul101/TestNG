package pom;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunction;

public class SignUpPOM {

private WebDriver driver;
	
	public SignUpPOM(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	By registerbutton=By.cssSelector("button[type='submit'][id='register-button']");
	By registercon=By.linkText("Register");
	By genderRadio=By.cssSelector("input[type='radio'][id='gender-male']");
	@FindBy(css = "input[type='text'][id='FirstName']")
	WebElement firstname;
	@FindBy(css = "input[type='text'][id='LastName']")
	WebElement lastname;
	@FindBy(css = "input[type='email'][id='Email']")
	WebElement email;
	@FindBy(css = "input[type='password'][id='Password']")
	WebElement password;
	@FindBy(css = "input[type='password'][id='ConfirmPassword']")
	WebElement confirmpassword;
	@FindBy(id = "Company")
	WebElement companyElement;
	
	
	public void RegisterIcon() {
		ReusableFunction.clickOn(registercon, Duration.ofSeconds(10));
	}
	public void PassData(String name1,String name2,String emailq,String pass1,String pass2,String comp) {
		ReusableFunction.clickOn(genderRadio, Duration.ofSeconds(10));
		ReusableFunction.sendText(firstname, name1);
		ReusableFunction.sendText(lastname, name2);
		ReusableFunction.sendText(email, emailq);
		ReusableFunction.sendText(companyElement, comp);
		ReusableFunction.sendText(password, pass1);
		ReusableFunction.sendText(confirmpassword, pass2);
	
	}
	public void clickregbtn() {
		ReusableFunction.clickOn(registerbutton,  Duration.ofSeconds(10));
	}
}
