package stepdefinitions;

import static org.testng.Assert.assertEquals;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import Base.ReusableFunctions;
import Pom.LoginPom;
import Pom.SignUpPom;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import utilities3.FileIO;


public class Login_Test {
	public WebDriver driver=Hooks.driver;
	ReusableFunctions reuse;
	Properties prop=FileIO.getProperties();
	LoginPom login;
	SignUpPom signup;
	
	
	@Given("User is on the site.")
	public void user_is_on_the_site() {
		signup=new SignUpPom(driver);
	    assertEquals(driver.getCurrentUrl(),"https://taruni.in/");
	}

	@When("User clicks on profile button")
	public void user_clicks_on_profile_button() throws InterruptedException {
		Thread.sleep(2000);
		signup.profClick();
	   
	}

	@When("User clicks on the SignUp button")
	public void user_clicks_on_the_sign_up_button() throws InterruptedException {
		Thread.sleep(2000);
		signup.SignupClick();
	    
	}

	@When("User enters {string} and {string} and {string}")
	public void user_enters_and_and(String string, String string2, String string3) throws InterruptedException {
	    Thread.sleep(2000);
	    signup.Details(string, string2, string3);
	    
	}

	@When("User clicks on the create account")
	public void user_clicks_on_the_create_account() throws InterruptedException {
		Thread.sleep(2000);
		signup.accountCreateClick();
	    
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//	@Given("User is on the login page of the site.")
//	public void user_is_on_the_login_page_of_the_site() {
//		login=new LoginPom(driver);
//		assertEquals(driver.getCurrentUrl(),"https://casekaro.com/");
//	    
//	}
//
//	@When("User clicks on profile button")
//	public void user_clicks_on_profile_button() throws InterruptedException {
////		login=new LoginPom(driver);
//		login.profClick();
//		
//	}
//
//	@When("User enters the email and login")
//	public void user_enters_the_email_and_login() {
//	    
//	}


}
