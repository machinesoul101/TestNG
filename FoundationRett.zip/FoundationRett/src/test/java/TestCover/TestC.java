package TestCover;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.Properties;

import org.apache.http.impl.cookie.RFC2109DomainHandler;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.DataProvider1;
import Base.DriverSetup;
import Base.ReusableFunctions;
import Pom.LoginPom;
import Pom.SignUpPom;
import utilities3.ExtentReportsListener;
import utilities3.FileIO;

@Listeners(ExtentReportsListener.class)
public class TestC {	
	
	WebDriver driver;
	ReusableFunctions ru;
	SignUpPom bc;
	LoginPom login;
	Properties prop=FileIO.getProperties();
	
	
	
	
	@BeforeTest
	public void openBrowser()
	{
		//driver = ReusableFunctions.invokeBrowser();
		driver=DriverSetup.invokeChromebrowser();
		ru = new ReusableFunctions(driver);
		ru.openWebsite();
		assertEquals(driver.getCurrentUrl(),prop.getProperty("test_url"));
	}
	
	
	
	
	@DataProvider(name="data2")
	public String[][] getData1() throws IOException{
	    String sheetname = "Sheet1";
	    return DataProvider1.passwordDP(sheetname);
	}
	
	
	
	
	
	
	
	
	@Test(priority = 1)
	public void profileCLick() throws InterruptedException {
		
        login=new LoginPom(driver);
        Thread.sleep(2000);
        login.profClick();
        assertEquals(driver.getCurrentUrl(),"https://taruni.in/account/login");
		
	}
	@Test(dataProvider="data2",priority = 2)
	public void emailAndPassword(String email1,String password1) throws InterruptedException {
		login=new LoginPom(driver);
		Thread.sleep(4000);
		login.emailAndPassword(email1, password1);
		
		
		
		
	}
	@Test(priority = 3)
	public void verify() throws InterruptedException {
		login=new LoginPom(driver);
		Thread.sleep(10000);//to solve captcha manually

		
		String s2 = login.verifyLogin();
		assertEquals(s2, "Your account");
	}


	
	

}