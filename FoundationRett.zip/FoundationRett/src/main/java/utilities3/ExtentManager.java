package utilities3;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;
	
	public static ExtentReports createInstance() throws IOException {
		
		String ext= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String repname="TestReport-"+ ext+".html";
		htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir")+"//Reports//TestNG//"+repname);
//		htmlReporter.loadXMLConfig(System.getProperty("user.dir")+"/src/test/resources/extent-config.xml");
		
		htmlReporter.config().setReportName("Rev Case Report");
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setDocumentTitle("Automation Report");
		
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("Host Name", "localhost");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("User Name", "roshan");
		return extent;
	}
	
	
}

