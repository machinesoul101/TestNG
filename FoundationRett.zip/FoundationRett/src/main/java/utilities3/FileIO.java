package utilities3;

import java.io.FileInputStream;
import java.util.Properties;

public class FileIO {

	private static Properties properties;

	public static Properties getProperties() {
		if (properties == null) {
			properties = new Properties();
			try {
				FileInputStream fis = new FileInputStream("C:\\Users\\268849\\eclipse-workspace\\FoundationRett\\TestResources\\ObjectRepository\\configuration.properties");
//				C:\Users\268849\eclipse-workspace\FoundationRett\TestResources\ObjectRepository\configuration.properties
				properties.load(fis);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return properties;
	}

}
