package Pom;



import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ReusableFunctions;


public class SignUpPom {
	
	public WebDriver driver;
	ReusableFunctions rF;
	
    public SignUpPom(WebDriver driver) {
        this.driver = driver;
        rF=new ReusableFunctions(driver);
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath = "//a[@class=\"mob-hide\"]") 
    WebElement profElement;
    @FindBy(xpath = "//div[@class=\"sign-up\"]//a[@class=\"register\"]")
    WebElement signUpClickElement;
    @FindBy(xpath = "//div[@class=\"fieldset\"]//div[1]//input[@id=\"input--template--22527716557093__main--customerfirst_name\"]")
    WebElement fullnameElement;
    @FindBy(xpath = "//div[@class=\"fieldset\"]//div[2]//input[@id=\"input--template--22527716557093__main--customeremail\"]")
    WebElement email1Element;
    @FindBy(xpath = "//div[@class=\"fieldset\"]//div[3]//input[@id=\"input--template--22527716557093__main--customerpassword\"]")
    WebElement passElement;
    @FindBy(xpath = "//*[@id=\"create_customer\"]/button")
    WebElement createAccountElement;
    
    
    public void profClick() throws InterruptedException {
    	Thread.sleep(2000);
    	rF.clickOnElement(profElement);
    	}
    
    public void SignupClick() throws InterruptedException {
    	Thread.sleep(2000);
    	rF.clickOnElement(signUpClickElement);
		
	}
    
    public void Details(String FullName,String emailString,String Password) throws InterruptedException {
    	
    	rF.sendText(fullnameElement, FullName);
    	Thread.sleep(1000);
    	rF.sendText(email1Element, emailString);
    	Thread.sleep(1000);
    	rF.sendText(passElement, Password);
    }
    
    public void accountCreateClick() {
    	rF.clickOnElement(createAccountElement);
    	
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

//    @FindBy(xpath = "//div[@class=\"rte scroll-trigger animate--slide-in\"]//div[2]//div[1]//div[1][text()='iPhone 15']")
//    private WebElement iphone15;
    
    
   
    
//    public void MobileSelection () throws InterruptedException {
//    	
//    	rF.clickOn(By.xpath("//div[@class=\"frame\"]//a[text()=\"Apple\"]"), Duration.ofSeconds(2));
//    	//rF.switchToNewTab();
//    	
//    }
//    
   
    
    
    
    

}
