package Pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ReusableFunctions;

public class LoginPom {
	
	
	public WebDriver driver;
	ReusableFunctions rF;
	
    public  LoginPom(WebDriver driver) {
        this.driver = driver;
        rF=new ReusableFunctions(driver);
        PageFactory.initElements(driver, this);
    }
    
    
    @FindBy(xpath = "//a[@class=\"mob-hide\"]") 
    WebElement profElement;
    @FindBy(xpath = "//div[@class=\"fieldset\"]//div[1]//input[@id=\"input--template--22527716557093__main--customeremail\"]")
    WebElement emailElement;
    @FindBy(xpath = "//div[@class=\"relative\"]//div[1]//input[@id=\"input--template--22527716557093__main--customerpassword\"]")
    WebElement passwordElement;
    @FindBy(xpath = "//*[@id=\"customer_login\"]/button")
    WebElement loginClickElement;
    @FindBy(xpath = "//div[@class=\"section-header text-start\"]//div[1]//h1[1]")
    WebElement accounElement;
    
    
   
    public void profClick() throws InterruptedException {
    	Thread.sleep(2000);
    	rF.clickOnElement(profElement);
    	}
    
    
    public void emailAndPassword(String email2, String password2) throws InterruptedException {
        Thread.sleep(2000);
        rF.sendText(emailElement, email2);
        rF.sendText(passwordElement, password2);
        Thread.sleep(1000);
        rF.clickOnElement(loginClickElement);
        
    }
    public String verifyLogin() {
    	String s1= rF.getElement(accounElement);
    	return s1;
    	
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
//    @FindBy(xpath = "//a[@class=\"header__icon header__icon--account link focus-inset small-hide\"]")
//    WebElement profElement;
    
//Thread.sleep(2000);
//	rF.clickOnElement(profElement);
   


}
