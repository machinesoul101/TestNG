package Base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities3.FileIO;

public class ReusableFunctions 
{
	private static WebDriver driver;
	private WebDriverWait wait;
	public static Properties prop;
	public static String browser_choice;
	
	
	public ReusableFunctions(WebDriver driver) 
	{
		ReusableFunctions.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		prop = FileIO.getProperties();
	}
	
	public void openWebsite() {

		try {
//			
			driver.get("https://taruni.in/");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}
	
	//method to retrive the test_url from config properties
	public void openBrowser(String websiteUrlKey) 
	{
		if (prop == null) 
		{
	        prop = FileIO.getProperties();
	    }
		try {
			System.out.println("Test_url: "+prop.getProperty(websiteUrlKey));
			driver.get(prop.getProperty(websiteUrlKey));

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	
	/********** click on any element *********/
	public void clickOnElement(WebElement element) {
		element.click();
	}
	
	
	/************** Switch to new tab ****************/
	public void switchToNewTab() {
		try {
			
			ArrayList<String> tabs = new ArrayList<String>(
			driver.getWindowHandles());
			driver.switchTo().window(tabs.get(tabs.size() - 1));
			
		} catch (Exception e) {
			e.printStackTrace();
			
			reportFail(e.getMessage());
		}
	}
	
	/********** wait for the element to display on the page *********/
	public void waitForElementToDisplay(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
		
		
		}
	
	public void switchToChildWindow() {
		String parent = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
//		System.out.println(set);
		for (String handle : set) {
			if (!handle.equals(parent)) {
				driver.switchTo().window(handle);
				System.out.println("Child window title: " + driver.getTitle());
			}
	
	
		}
		}
	
	//for invoking the browser with the data from config properties
	public static WebDriver invokeBrowser() 
	{
		if(prop==null)
		{
			prop=FileIO.getProperties();
		}
		browser_choice = prop.getProperty("browser");
		System.out.println("Test_Browser: "+ browser_choice);
		try 
		{
			if (browser_choice.equalsIgnoreCase("edge")) 
			{
				driver = DriverSetup.invokeEdgebrowser();
			} 
			else if (browser_choice.equalsIgnoreCase("chrome"))
			{
				driver = DriverSetup.invokeChromebrowser();
			} 
			else
			{
				throw new Exception("Invalid browser name provided in property file");
			}
		}
		catch (Exception e) 
		{
				e.printStackTrace();
		}
		
		return driver;
	}
	
	
    /********* Report fail Test **********/
	public static void reportFail(String message) {
			Assert.fail("Testcase Failed: " + message);
		}
	public void performAction() {
			
			Alert alert = driver.switchTo().alert();
			// Accept the alert (clicking "OK")
			alert.accept();
			}
	    
	
	
	
	
	//for clicking a webelement 
	public void clickOn(By locator, Duration timeout) 
	{
		try 
		{
			new WebDriverWait(driver, timeout).until(ExpectedConditions
					.elementToBeClickable(locator));
			driver.findElement(locator).click();
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	//sending text to web element
	public void sendText(WebElement element, String text) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOf(element));

			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
	//getting the text from the element
	public String getText(By locator) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.presenceOfElementLocated(locator));
			text = driver.findElement(locator).getText();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return text;
	}
	
	public String getElement(WebElement element) {
	    String text = null;
	    try {
	        new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
	        text = element.getText();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return text;
	}

	

	public static void takeScreenShot(String filepath) {
		TakesScreenshot takeScreenShot=(TakesScreenshot) driver;
		File srcFile=takeScreenShot.getScreenshotAs(OutputType.FILE);
		File destFile=new File(filepath);
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void scrollToElement(WebElement element) {
	    try {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    } catch (Exception e) {
	        e.printStackTrace();
	        reportFail(e.getMessage());
		}
	    
	    
	 
	    
	    
	

}
}



