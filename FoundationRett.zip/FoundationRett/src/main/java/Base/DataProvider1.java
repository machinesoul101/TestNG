package Base;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataProvider1 {

	
	public static String[][] passwordDP(String sheet) throws IOException {
		
		FileInputStream file = new FileInputStream("C:\\Users\\268849\\eclipse-workspace\\FoundationRett\\ExcelFile\\Book10.xlsx");					
		
		//C:\Users\268849\eclipse-workspace\RevCaseKaro\ExcelFile\Book10.xlsx
		Workbook workbook = new XSSFWorkbook(file);
		Sheet sheet1 = workbook.getSheet(sheet);
		int rowCount = sheet1.getPhysicalNumberOfRows();
		Row row = sheet1.getRow(0);
		int colCount = row.getPhysicalNumberOfCells();
		
        String data[][] = new String[rowCount][colCount];
		
		DataFormatter df = new DataFormatter();
		for(int i=0; i<rowCount; i++) {
			for(int j=0; j<colCount; j++) {
				data[i][j]=df.formatCellValue(sheet1.getRow(i).getCell(j));
				
			}
		}
		return data;
		
	}
}
